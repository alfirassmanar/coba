<?php
require_once 'fungsi-crud.php';
if (isset($_POST)) {
    extract($_POST);
    delete($table = "tb_mahasiswa", $where = "id = '$id'");
    echo "<script>location='index.php'</script>";
}