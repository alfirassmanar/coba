<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body>

    <?php
    require_once 'fungsi-crud.php';

    koneksi();
    ?>

    <div class="tambah">
        <a href="create.php"><button>TAMBAH Mahaiswa</button></a>
    </div>
    <div class="pencarian">
        <form action="" method="get" style="display: inline;">

            <input type="text" name="cari" value="<?= isset($cari) ? $cari : "" ?>" autofocus placeholder="Cari" id="">
            <button type="submit" name="proses">Search</button>
        </form>
        <a href="logout.php"><button>Logout</button></a>
    </div>

    <table border="1" width="100%" style="margin-top: 25px;">
        <tr>
            <th>NO</th>
            <th>Nim</th>
            <th>Nama</th>
            <th>Tgl Lahir</th>
            <th>Jenis Kelamin</th>
            <th>Prodi</th>
            <th>NO TLPN</th>
            <th>Alamat</th>
            <th>Pendidikan</th>
            <th>Action</th>
        </tr>
        <?php
        $list_mhs = getAllData($table = "tb_mahasiswa");
        $no = 1;
        foreach ($list_mhs as $item) {
        ?>
        <tr>
            <td><?= $no++; ?></td>
            <td><?= $item['nim'] ?></td>
            <td><?= $item['nama'] ?></td>
            <td><?= $item['tgl_lahir'] ?></td>
            <td><?= $item['jekel'] ?></td>
            <td><?= $item['prodi'] ?></td>

            <td><?= $item['notlpn'] ?></td>
            <td><?= $item['alamat'] ?></td>
            <td><?= $item['pendidikan'] ?></td>
            <td>
                <a href="update.php?id=<?= $item['id'] ?>"><button type="button">Edit</button></a>
                <form action="delete.php" method="post" style="display: inline;">
                    <input type="hidden" name="id" value="<?= $item['id'] ?>" id="">
                    <input type="submit"
                        onclick="return confirm('Apakah anda yakin ingin hapus NIM : <?= $item['nim'] ?>')"
                        value="Hapus">
                </form>
            </td>
        </tr>
        <?php
        }
        ?>
    </table>

</body>

</html>