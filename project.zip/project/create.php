<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <?php

    require_once 'fungsi-crud.php';

    ?>

    <?php
    extract($_POST);
    if (isset($proses)) {
        $list_pendidikan = [];
        if (isset($SD)) {
            $list_pendidikan[] = $SD;
        }
        if (isset($SMP)) {
            $list_pendidikan[] = $SMP;
        }
        if (isset($SMA)) {
            $list_pendidikan[] = $SMA;
        }
        if (isset($D3)) {
            $list_pendidikan[] = $D3;
        }

        if (count($list_pendidikan) > 0) {
            //SD,SMP,SMA,D3//
            $pendidikan = implode(",", $list_pendidikan);
        } else {
            //
            $pendidikan = "";
        }

        $data = [
            'nim' => $nim,
            'nama' => $nama,
            'tgl_lahir' => $tglLahir,
            'jekel' => $jekel,
            'prodi' => $prodi,
            'notlpn' => $tlp,
            'alamat' => $alamat,
            'pendidikan' => $pendidikan,

        ];

        $simpan = insert($table = "tb_mahasiswa", $data);

        if ($simpan) {
            echo "<script>location='index.php'</script>";
        } else {
            echo "Data mahasiswa Gagal di simpan";
        }
    }
    ?>
    <form action="" method="post">
        <table>
            <tr>
                <td>Nim</td>
                <td>:</td>
                <td><input type="number" required name="nim" id="" placeholder="Exam : 223234343"></td>
            </tr>
            <tr>
                <td>Nama</td>
                <td>:</td>
                <td><input type="text" required name="nama" id=""></td>
            </tr>
            <tr>
                <td>Tanggal Lahir</td>
                <td>:</td>
                <td><input type="date" required name="tglLahir" id=""></td>
            </tr>
            <tr>
                <td>Jenis Kelamin</td>
                <td>:</td>
                <td>
                    <input type="radio" name="jekel" id="" checked value="Pria">Pria
                    <input type="radio" name="jekel" id="" value="Wanita">Wanita
                </td>
            </tr>
            <tr>
                <td>Prodi</td>
                <td>:</td>
                <td>
                    <select name="prodi">
                        <option value="Manajemen Informatika">Manajemen Informatika</option>
                        <option value="Teknik Komputer">Teknik Komputer</option>
                        <option value="Teknologi Rekayasa Perangkat Lunak">Teknologi Rekayasa Perangkat Lunak</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td>No Tlpn</td>
                <td>:</td>
                <td><input type="tel" required name="tlp" id=""></td>
            </tr>
            <tr>
                <td>Alamat</td>
                <td>:</td>
                <td><textarea name="alamat" id="" required cols="30" rows="10"></textarea></td>
            </tr>
            <tr>
                <td>Pendidikan</td>
                <td>:</td>
                <td>
                    <input type="checkbox" name="SD" id="" value="SD">SD
                    <input type="checkbox" name="SMP" id="" value="SMP">SMP
                    <input type="checkbox" name="SMA" id="" value="SMA">SMA
                    <input type="checkbox" name="D3" id="" value="D3">D3
                </td>
            </tr>

            <tr>
                <td colspan="3">
                    <input type="submit" value="Proses" name="proses">
                    <input type="reset" value="Reset">
                </td>
            </tr>

        </table>
    </form>



</body>

</html>